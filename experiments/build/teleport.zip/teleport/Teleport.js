import * as RODIN from 'rodin/core';

export class Teleport {
    constructor(sourceObject, segmentsMaxNumber = 50, step = 0.1) {

        this.sourceObject = sourceObject;
        this.segmentsMaxNumber = segmentsMaxNumber;
        this.step = step;

        this.sourceObject.on(RODIN.CONST.READY, () => {
            this.createLine(this.sourceObject._threeObject.getWorldDirection());
        });

        this.sourceObject.on(RODIN.CONST.UPDATE, () => {
            this.reDrawLine(this.sourceObject._threeObject.getWorldDirection());
        });
    }

    createLine(rayDirection){
        rayDirection = rayDirection.normalize();
        this.parabola = new RODIN.Parabola(rayDirection, -9.8, 0, 0);

        const pointsSculpt = new RODIN.Sculpt();
        for (let i = 0; i < this.segmentsMaxNumber; i++) {
            const point = new RODIN.Sphere(0.02, new THREE.MeshBasicMaterial({color: 0x00FF00}));
            point.position.copy(this.parabola.eval(this.step * i));
            pointsSculpt.add(point);
        }
        RODIN.Scene.add(pointsSculpt);
        this.pointsSculpt = pointsSculpt;
        this.raycaster = new RODIN.Raycaster();
        this.raycaster.distance = this.segmentsMaxNumber * this.step;
    }

    reDrawLine(rayDirection) {
        rayDirection = rayDirection.normalize();

        // calculate angle between ray vector and XZ plane, for projection it in 2D
        let rayDirectionOnXZ = new RODIN.Vector3(rayDirection.x, 0, rayDirection.z);
        let alpha = -rayDirectionOnXZ.angleTo(rayDirection) * Math.sign(rayDirection.y || 1);

        // calculate coefficient for acceleration, which is equal [0, 1]
        const lerpFactor = Math.pow(alpha / Math.PI + 1 / 2, 3);

        this.parabola.direction = rayDirection;
        this.parabola.a = -lerpFactor;
        this.parabola.b = Math.tan(alpha);
        this.parabola.c = 0;
        this.parabola.shift = this.sourceObject.globalPosition;

        for (let i = 0; i < this.pointsSculpt.children.length; i++) {
            if(this.step * i < this.raycaster.closest){
                this.pointsSculpt.children[i].position.copy(this.parabola.eval(this.step * i));
            }else{
                this.pointsSculpt.children[i].position.copy(this.pointsSculpt.children[0].position);
            }

        }

        this.pointsSculpt.globalPosition.set(0,0,0);
        this.pointsSculpt.globalQuaternion.set(0, 0, 0, 1);
        this.pointsSculpt.globalScale.set(1, 1, 1);
    }

    getIntersection(){
        return this.raycaster.raycastCurve(this.parabola);
    }
}


